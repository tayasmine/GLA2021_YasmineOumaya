import java.time.LocalDate;
import java.time.LocalTime;

public class Flight  {
	String airport;
	String direction;
	LocalDate date;
	LocalTime time;
	LocalTime Duration;
	int price;
	String flighttype;
	String appointment;
	int availableseats;
	
	
	
	
	
}
