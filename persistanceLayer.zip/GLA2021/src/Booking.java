
public interface Booking {

}
