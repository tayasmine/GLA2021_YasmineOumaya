
public class Pilot implements Users {
	 String identifiant = "";
	 String password = "";
	 @Override
	public void login(String id,String pw) {
		System.out.print("Your login is  "+id+" and your pw is" + pw);
		
	
	}

}
