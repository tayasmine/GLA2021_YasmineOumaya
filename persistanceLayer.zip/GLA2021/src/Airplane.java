
public class Airplane {
	int airplaneid;
	String airplanetype;
	int numberofseats;
	Flight[] previous;

}
