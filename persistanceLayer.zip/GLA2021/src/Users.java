
public interface Users {
	
	
	public void login(String id,String pw);
	

}
