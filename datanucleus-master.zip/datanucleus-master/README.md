# datanucleus

A simple project to setup DataNucleus into Eclipse.
The database is HsqlDB (in-memory). Its configuration can be checked into the "META-INF/persistence.xml" file.
