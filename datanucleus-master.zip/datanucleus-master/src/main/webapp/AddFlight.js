function putServerData(url, data, success){

    $.ajax({
		type: 'PUT',	
        url: url, 
		data: data,
		contentType : 'application/json',
        dataType: "json"
    }).done(success);
}


function callDone(result){
	
		
}
		

	
	$("#addFlightButton").click(function(){
		console.log("create flight");
        let userID = JSON.parse(localStorage.getItem('userID'));

        newAircraft = {
            tailnumber: $("#tailnumber").val(),
            aircrafttype: $("#aircrafttype").val(),
            numberofseats: $("#numberofseats").val()
        }
		new Flight = {
			"departure":				$('input[name="departure"]').val(),
			"direction":			$('input[name="direction"]').val(),
			"date":					$('input[name="date"]').val(),
			"duration":				$('input[name="duration"]').val(),
			"price":				$('input[name="price"]').val(),
			"flighttype":	$('input[name="flighttype"]').val(),
			"appointment":			$('input[name="appointment"]').val(),
			"availableseats":				$('input[name="availableseats"]').val(),
			"description":			$('input[name="description"]').val(),
			"pilotid":			$('input[name="pilotid"]').val(),
			"aircrafttype":			$('input[name="aircrafttype"]').val(),
		}
		data=JSON.stringify(args);
		putServerData("ws/Flight/addFlight",data, isFlightValid);
	});
});