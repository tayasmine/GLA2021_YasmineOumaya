function getServerData(url, success){
    $.ajax({
        dataType: "json",
        url: url
    }).done(success);    
}

function callDone(result){
	var templateExample = _.template($('#templateExample').html());
	result.forEach(f => {
	
	var html = templateExample({
		"attribute":JSON.stringify(f)
	});

	$("#result").append(html);});
}

$(function(){
	$("#SHOW").click(function(){
		getServerData("ws/Flight/All",callDone);
	});
});