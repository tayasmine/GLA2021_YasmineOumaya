function hide_scroll(){
	var scr = document.getElementById("fly");
	scscr.style.display = "none";
}

function show_scroll(){
	var scr = document.getElementById("fly");
	x.style.display = "block";
}



function getServerData(url, success){
    $.ajax({
        dataType: "json",
        url: url
    }).done(success);    
}

function callDone(result){
	var templateExample = _.template($('#templateExample').html());
	result.forEach(f => {
	
	var html = templateExample({
		"attribute":JSON.stringify(f)
	});

	$("#result").append(html);});
}

$(function(){
	$("#SHOW").click(function(){
		getServerData("ws/Flight/All",callDone);
	});
});