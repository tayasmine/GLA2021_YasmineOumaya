package com.tsiy.dao;

public interface PilotDAO extends DAO<Pilot> {
	

}
